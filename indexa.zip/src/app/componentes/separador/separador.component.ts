import { Component } from '@angular/core';

@Component({
  selector: 'app-separador',
  standalone: true,
  imports: [],
  templateUrl: './separador.component.html',
  styleUrl: './separador.component.css'
})
export class SeparadorComponent {

}
